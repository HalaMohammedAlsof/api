create table dojo_courses (
	course text,
	description text
);

insert into dojo_courses(course, description) values ('DevOps', 'Learn DevOps and get six figure salary');
insert into dojo_courses(course, description) values ('Cyber Security', 'Secure your cloud infrastructure');
insert into dojo_courses(course, description) values ('Digital Marketing', 'Learn how to do digital marketing');
insert into dojo_courses(course, description) values ('ARVRs', 'Make AR VR games');